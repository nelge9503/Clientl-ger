# Client-leger
- Création d'un site web et d'une page administrative pour une auto école. 
- Le site web n'étant pas encore complet vous y verez des pages vides ou incomplète.
- Lien du site web : https://fast-permis.000webhostapp.com/
- Vous trouverez le code du site et de la page d'administration dans les fichiers ci-dessus
